// В этом файле только переходы между страницами после function написан id а ниже после знака равно то куда перекидывает 
function tovar1() {
    window.location.href = "Товар.html";
}

function tovar2() {
    window.location.href = "Товар2.html";
}

function tovar3() {
    window.location.href = "Товар3.html";
}

function tovar4() {
    window.location.href = "Товар4.html";
}

function entrance() {
    window.location.href = "Вход.html";
}

function registration() {
    window.location.href = "Регистрация.html";
}

function anime_goods() {
    window.location.href = "Товары.html";
}

function anime_goods2() {
    window.location.href = "Товары_2.html";
}

function anime_goods3() {
    window.location.href = "Товары_3.html";
}

function anime_goods4() {
    window.location.href = "Товары_4.html";
}

function index() {
    window.location.href = "index.html";
}

function basket() {
    window.location.href = "Корзина.html";
}

function reviews() {
    window.location.href = "Отзовы.html";
}

function contacts() {
    window.location.href = "Контакты.html";
}